<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['client_id'] = 'your-client-id';
$config['client_secret'] = 'your-secret-key';