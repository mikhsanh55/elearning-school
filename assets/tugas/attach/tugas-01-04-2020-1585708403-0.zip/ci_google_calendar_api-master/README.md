# Code Ignitter 3 - Google Calendar Api Example

## Welcome to Exapmle

Step 1: Go to google api credentials. Take your OAuth cilient id and secret key, its [here](https://developers.google.com/google-apps/calendar/quickstart/php ) You can use wizard on quickstart page.

Step 2: Enter your client id and secret key to application/config/calendar.php file

Step 3: Set your application base_url on application/config/config.php

Ready! its run.


## Important
You must enter authorization redirect URI in your google api project settings.
For example **http://yourhost/auth/oauth** login progress in auth/oauth url
